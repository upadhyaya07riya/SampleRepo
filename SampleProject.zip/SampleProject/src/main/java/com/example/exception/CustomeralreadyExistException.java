package com.example.exception;

public class CustomeralreadyExistException extends Exception {
	public CustomeralreadyExistException(String msg) {
		super(msg);
	}
}
