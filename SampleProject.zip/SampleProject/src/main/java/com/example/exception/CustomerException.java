package com.example.exception;

public class CustomerException extends Exception {
	public CustomerException() {
		super();
	
	}

	public CustomerException(String message) {
		super(message);

	}


}
