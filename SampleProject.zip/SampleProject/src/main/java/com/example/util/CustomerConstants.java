package com.example.util;

public class CustomerConstants {
	public static final String VIEW_CUSTOMER_URL="viewcustomer/{id}";
	public static final String CUSTOMER_NOT_FOUND="Customer not found ";
	public static final String CUSTOMER_ADD_URL="addcustomer";
	public static final String CUSTOMER_ALREADY_EXIST="id already exist";
	public static final String CUSTOMER_ADDED="Customer added successfully  ";
    public static final String CUSTOMER_DELETED=" customer deleted successfully";
	public static final String CUSTOMER_DELETE_URL="removecustomer/{customerId}";
	
}
