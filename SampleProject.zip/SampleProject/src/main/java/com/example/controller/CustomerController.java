package com.example.controller;

import java.util.Optional;
import com.example.exception.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.util.*;
import com.example.dto.SuccessMessage;
import com.example.entity.Customer;
import com.example.exception.CustomerNotFoundException;
import com.example.service.CustomerServiceImpl;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	private CustomerServiceImpl customerservice;
	
	

	@GetMapping(CustomerConstants.VIEW_CUSTOMER_URL)
	public ResponseEntity<Optional<Customer>> getCustomer(@PathVariable(value="id") int id)throws CustomerNotFoundException
	{
		return customerservice.getCustomerId(id);
	}
	
	@GetMapping(CustomerConstants.CUSTOMER_ADD_URL)
	public SuccessMessage addCustomer(@RequestBody Customer customer) throws CustomeralreadyExistException {
		
		return new SuccessMessage(customerservice.addCustomer(customer));
	}

	@GetMapping(CustomerConstants.CUSTOMER_DELETE_URL)
	public SuccessMessage removeCustomer(@PathVariable(value="customerId") int customerId) throws CustomerNotFoundException {
		
		return new SuccessMessage(customerservice.removeCustomer(customerId));
	}
}
