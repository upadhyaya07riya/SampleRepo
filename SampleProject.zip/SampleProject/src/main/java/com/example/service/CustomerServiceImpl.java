package com.example.service;

import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.example.dao.CustomerRepository;
import com.example.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.util.*;
import com.example.entity.Customer;
import com.example.exception.CustomerNotFoundException;
import com.example.exception.CustomeralreadyExistException;
import com.example.service.CustomerServiceImpl;


public class CustomerServiceImpl {

	@Autowired
	private CustomerRepository customerDao;
	
	public ResponseEntity<Optional<Customer>> getCustomerId(int id) throws CustomerNotFoundException {
		
		Optional<Customer> customer=customerDao.findById(id);
				if(customer.isPresent()) {
					return ResponseEntity.ok().body(customer);
				}
				else
				{
			   	throw new CustomerNotFoundException(CustomerConstants.CUSTOMER_NOT_FOUND);
				}

}
	public String addCustomer(Customer customer) throws CustomeralreadyExistException {
		
		Optional<Customer> customerId  = customerDao.findById(customer.getId());
		
		if(customerId.isPresent())
		{
			throw new CustomeralreadyExistException(CustomerConstants.CUSTOMER_ALREADY_EXIST);
			
		}
		customer.setId(customer.getId());
		customerDao.save(customer);
		return CustomerConstants.CUSTOMER_ADDED;
		
	}
	public String removeCustomer(int Id) throws CustomerNotFoundException {
		
		Optional<Customer> customerId  = customerDao.findById(Id);
				
				if(customerId.isPresent())
				{
					customerDao.deleteById(Id);
					return 	CustomerConstants.CUSTOMER_DELETED;
					
				}
				else
				{
					return CustomerConstants.CUSTOMER_NOT_FOUND;
				}


			}
}
