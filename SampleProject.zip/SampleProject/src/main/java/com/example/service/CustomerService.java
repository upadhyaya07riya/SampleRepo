package com.example.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.util.*;
import com.example.entity.Customer;
import com.example.exception.CustomerNotFoundException;
import com.example.exception.CustomeralreadyExistException;
import com.example.service.CustomerServiceImpl;

public interface CustomerService {
	public ResponseEntity<Optional<Customer>> getCustomerId(int id) throws CustomerNotFoundException ;
	public String addCustomer(Customer customer) throws CustomeralreadyExistException;
	public String removeCustomer(int Id) throws CustomerNotFoundException ;

}
