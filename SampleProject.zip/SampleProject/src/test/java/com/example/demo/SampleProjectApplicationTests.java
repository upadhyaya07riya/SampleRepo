package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import com.example.entity.*;
import com.example.service.CustomerService;
import com.example.exception.*;

@SpringBootTest
class SampleProjectApplicationTests {
	@Autowired 
	 private CustomerService  customerService;
	
	@Test
	public void addCustomer() throws CustomerException, CustomeralreadyExistException {
		String expected="Customer is added Sucessfully";
		Customer cst=new Customer();
		
		cst.setId(3);
		cst.setName("Mamta");
		cst.setAge(46);
		cst.setAddress(" Agra ");
		cst.setSalary(45000);
		
        String actual = customerService.addCustomer(cst);
           Assertions.assertEquals(expected, actual);
	}

}
